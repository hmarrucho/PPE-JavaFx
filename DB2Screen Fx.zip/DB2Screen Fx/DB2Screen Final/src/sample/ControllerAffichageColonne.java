package sample;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.net.URL;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;


public class ControllerAffichageColonne implements Initializable {
    @FXML private TextField txt_nom_champ;
    @FXML private TextField txt_nomFichier;
    @FXML private ComboBox cb_colonne;
    @FXML private ComboBox cb_type_champ;
    @FXML private Button bt_enregistrer;
    @FXML private Button bt_creation_form;
    @FXML private RadioButton br_get;
    @FXML private RadioButton br_post;
    @FXML private TableView<Table> liste_enregistrement;
    @FXML private TableColumn<Enregistrement, String> tb_nom_colonne;
    @FXML private TableColumn<Enregistrement, String> tb_nom_champ;
    @FXML private TableColumn<Enregistrement, String> tb_type_champ;

    private Connexion connexion;
    private Table table;
    private Base base;
    private Colonne colonne;
    private ArrayList<Colonne> listeColonne;
    private ArrayList<Ligne> donnees;
    private String lesdonnees[];
    private String methode;
    private int indexTypeChamp;
    private ArrayList<Enregistrement> enregistrements;
    private ObservableList lesEnregistrementObserves = FXCollections.observableArrayList();

    @Override
    public  void initialize(URL url, ResourceBundle resourceBundle){

        tb_nom_colonne.setCellValueFactory(
                new PropertyValueFactory<Enregistrement, String>("nomColonne"));
        tb_nom_champ.setCellValueFactory(
                new PropertyValueFactory<Enregistrement, String>("nomChamp"));
        tb_type_champ.setCellValueFactory(
                new PropertyValueFactory<Enregistrement, String>("typeChamp"));

        liste_enregistrement.setItems(lesEnregistrementObserves);
        enregistrements = new ArrayList<Enregistrement>();

        bt_enregistrer.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                String nomColonne = cb_colonne.getSelectionModel().getSelectedItem().toString(); //récupère nom de la colonne
                String nomChamp = txt_nom_champ.getText(); // récupère nom du champ
                String typeChamp = cb_type_champ.getSelectionModel().getSelectedItem().toString(); // récupère type du champ
                indexTypeChamp = cb_type_champ.getSelectionModel().getSelectedIndex(); // récupère l'index du champ

                colonne = rechercheParNom(nomColonne);


                if(cb_type_champ.getSelectionModel().getSelectedIndex() == 2){ // si liste déroulante est sélectionnée
                    colonne = rechercheParNom(nomColonne);

                    try{
                        connexion.getDonneeColonnes(table, base, colonne);
                    }catch (SQLException ex){
                        ex.printStackTrace();
                    }

                    donnees = colonne.getLesLignes();
                    int nbligne = retourneNbLignes(donnees);
                    lesdonnees = new String[nbligne];
                    int i = 0;
                    for(Ligne l: donnees){
                        lesdonnees[i] = l.GetNom();
                        i++;
                    }

                    Enregistrement enregistrement = new Enregistrement(nomChamp, typeChamp, indexTypeChamp, nomColonne, lesdonnees);
                    enregistrements.add(enregistrement);
                    lesEnregistrementObserves.add(enregistrement); //ajoute l'objet instancié si dessus

                    int index = cb_colonne.getSelectionModel().getSelectedIndex();  // récupère l'index de l'élément sélectionné de la comboBox
                    cb_colonne.getItems().remove(index); // supprime l'élément sélectionné de la comboBox

                }else{
                    Enregistrement enregistrement = new Enregistrement(nomChamp, typeChamp, indexTypeChamp, nomColonne);
                    enregistrements.add(enregistrement);
                    lesEnregistrementObserves.add(enregistrement); //ajoute l'objet instancié si dessus

                    //ComboBox
                    int index = cb_colonne.getSelectionModel().getSelectedIndex();  // récupère l'index de l'élément sélectionné de la comboBox
                    cb_colonne.getItems().remove(index); // supprime l'élément sélectionné de la comboBox
                }
            }
        });

        bt_creation_form.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                if(br_get.isSelected()){
                    methode = "GET";
                }else{
                    methode = "POST";
                }
                try{
                    String nomFichier = txt_nomFichier.getText();
                    String nomTable = table.getNom();
                    if(!nomFichier.isEmpty()){  //si nom du fichier est spécifié
                        CreerFichier.creerForm(methode, nomTable, enregistrements, nomFichier);
                    }else{
                        System.out.println("Entrez un nom");
                    }
                }catch (Exception ex) {
                    ex.printStackTrace();
                }
            }});
    }

    public void setListeColonne(ArrayList<Colonne> listeColonne) {
        this.listeColonne = listeColonne;
        for(Colonne c : listeColonne){
            String nom = c.getNomcolonne();
            cb_colonne.getItems().add(nom); //ajoute un nom dans la liste déroulante
        }
        cb_colonne.getSelectionModel().selectFirst(); //sélectionne par défaut le premier élément de la liste

    }

    public void setConnexion(Connexion c){
        this.connexion = c;
    }

    public void setTable(Table table) {
        this.table = table;
    }

    public void setBase(Base base) {
        this.base = base;
    }

    public Colonne rechercheParNom(String nom){
        boolean trouve = false;
        Colonne c = null;
        int i = 0;

        while((trouve == false)&&(i < this.listeColonne.size())){
            c = this.listeColonne.get(i);
            if (c.getNomcolonne() == nom){
                trouve = true;
            }
            i++;
        }
        if (trouve){
            return c;
        }else{
            return null;
        }
    }

    public int retourneNbLignes(ArrayList<Ligne> donnees){
        int nbligne = 0;
        for(Ligne l: donnees){
            nbligne++;
        }
        return nbligne;
    }
}


