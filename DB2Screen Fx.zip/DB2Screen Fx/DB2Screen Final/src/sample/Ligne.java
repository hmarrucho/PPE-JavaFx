package sample;

/**
 * Created with IntelliJ IDEA.
 * User: Flo
 * Date: 10/11/13
 * Time: 13:43
 * To change this template use File | Settings | File Templates.
 */
public class Ligne {
    //attributs
    private String nom;

    //accesseurs
    public String GetNom(){
        return this.nom;
    }

    public void SetNom(String nom){
        this.nom = nom;
    }

    //constructeur
    public Ligne(String unnom){
        this.nom = unnom;
    }

    //méthode
    public String toString(){
        return this.nom;
    }
}
