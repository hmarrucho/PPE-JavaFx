package sample;

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;

/**
 * Created with IntelliJ IDEA.
 * User: Flo
 * Date: 13/11/13
 * Time: 21:21
 * To change this template use File | Settings | File Templates.
 */
public class CreerFichier {

    public static File creerUnFichier(String nom) throws IOException{
        File fichier = null;
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(".")); //ouvre la boite de dialogue et affiche le répertoire courant
        fileChooser.setDialogTitle("Enregistrer sous"); //modifie le titre de la boite de dialogue

        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); //n'affiche que les répertoires
        String approve = new String("Enregistrer"); //Nom du bouton pour enregistrer = "Enregistrer"
        int resultatEnregistrer = fileChooser.showDialog(fileChooser, approve); //crée la fenêtre

        if(resultatEnregistrer == JFileChooser.APPROVE_OPTION){  //si clic sur Enregister
            String chemin = fileChooser.getSelectedFile().getAbsolutePath()+"\\"; //récupère le chemin absolue du dossier sélectionné
            fichier = new File(chemin, nom+".html");
            fichier.createNewFile(); //crée le fichier
        }
        return fichier;
    }

    /*Méthode static qui reçois en paramètre :
        String methode : correspond à la method du formulaire (GET, POST)
        String nomtable : correspond au nom (name) du formualaire
        ArrayList enregistrement: correspond à toutes les données enregistré
        String nomFichier : correspond au nom du fichier
     */
    public static void creerForm(String methode, String nomTable, ArrayList<Enregistrement> enregistrements, String nomFichier) throws IOException{
        File ff = creerUnFichier(nomFichier);
        ff.createNewFile();
        FileWriter ffw=new FileWriter(ff);
        ffw.write("<form name='"+nomTable+"' method='"+methode+"'>");  // écrire une ligne dans le fichier test.txt
        ffw.write("\r\n");
        for(Enregistrement enr : enregistrements){
            if(enr.getIndexTypeChamp()==2){ // Si index du type champ est égal à 2 donc si c'est une liste déroulante
                int longueurTableau = enr.getLesDonnees().length;
                String tableauDonnee[] = new String [longueurTableau];
                tableauDonnee = enr.getLesDonnees();
                ffw.write("<label>"+enr.getNomChamp()+"</label><select name='"+enr.getNomChamp()+"' > \r\n");
                for(int i=0; i<longueurTableau; i++){
                    ffw.write("<option value='"+tableauDonnee[i]+"'>"+tableauDonnee[i]+"</option>");
                    ffw.write("\r\n");
                }
                ffw.write("</select>\r\n");
            }else{
                ffw.write("<label>"+enr.getNomChamp()+"</label><input type='"+enr.getTypeChamp()+"' name='"+enr.getNomChamp()+"' >");
                ffw.write("\r\n");
            }
        }
        ffw.write("</form>");
        ffw.write("\r\n"); // forcer le passage à la ligne
        ffw.close(); // fermer le fichier à la fin des traitements
    }

}
