package sample;

import java.util.ArrayList;

/**
 * Created with IntelliJ IDEA.
 * User: fmuller85
 * Date: 06/11/13
 * Time: 17:20
 * To change this template use File | Settings | File Templates.
 */
public class Enregistrement {
    //attributs
    private String nomChamp;
    private int indexTypeChamp;
    private String typeChamp;
    private String nomColonne;
    private String lesDonnees[];

    public int getIndexTypeChamp() {
        return indexTypeChamp;
    }

    public void setIndexTypeChamp(int indexTypeChamp) {
        this.indexTypeChamp = indexTypeChamp;
    }

    public String getNomChamp() {
        return nomChamp;
    }

    public void setNomChamp(String nomChamp) {
        this.nomChamp = nomChamp;
    }

    public String getTypeChamp() {
        return typeChamp;
    }

    public void setTypeChamp(String typeChamp) {
        this.typeChamp = typeChamp;
    }

    public String getNomColonne() {
        return nomColonne;
    }

    public void setNomColonne(String nomColonne) {
        this.nomColonne = nomColonne;
    }

    public String[] getLesDonnees() {
        return lesDonnees;
    }

    public void setLesDonnees(String[] lesDonnees) {
        this.lesDonnees = lesDonnees;
    }

    //Constructeur
    public Enregistrement(String nomChamp, String typeChamp, int index, String nomColonne, String lesdonnees[]) {
        this.nomChamp = nomChamp;
        this.typeChamp = typeChamp;
        this.nomColonne = nomColonne;
        this.lesDonnees = lesdonnees;
        this.indexTypeChamp = index;
    }

    public Enregistrement(String nomChamp, String typeChamp, int index, String nomColonne) {
        this.nomChamp = nomChamp;
        this.typeChamp = typeChamp;
        this.nomColonne = nomColonne;
        this.indexTypeChamp = index;
    }


}
